"""
app.py
AML Compliance Intelligence - single-file, top-tab-nav portfolio app
(rebuilt from scratch, architecture mirrors the D'Agostino Legal
portfolio piece: one entrypoint, a full-width tab bar in place of a
sidebar page list, dark charcoal / cream / brass theme, no icons).

Tabs: Overview - Customers - Screening & Cases - Transactions -
Onboarding & Reviews - Team - Simulator.
"""

import pandas as pd
import streamlit as st

from db_utils import load_all
from report_utils import (
    detect_structuring, detect_rapid_movement, detect_high_risk_wires,
    HIGH_RISK_COUNTRIES_DEFAULT,
)
from workflow_utils import CASE_STATUSES, ALERT_DISPOSITIONS
from theme import (
    inject_css, hero, section_title, kpi_card, kpi_card_trend, risk_pill, status_pill_html,
    matrix_table_html, bar2d_chart, grouped_bar2d_chart, line_area_chart, donut_chart,
    bullet_kpi_chart, waterfall2d_chart, scatter2d_chart, brass_gradient,
    RISK_COLOR_MAP, BRASS, TEAL_ACCENT, SAGE, DUSTY_BLUE, HIGH, MEDIUM, LOW, CRITICAL,
)

st.set_page_config(page_title="AML Compliance Intelligence", layout="wide")
inject_css()

data = load_all()
customers, transactions, screening = data["customers"], data["transactions"], data["screening"]
cases, businesses, ubo = data["cases"], data["businesses"], data["ubo"]
alerts, audit_log = data["alerts"], data["audit_log"]

hero(
    "AUSTRAC / TRANCHE 2 COMPLIANCE",
    "AML Compliance Intelligence",
    "Customer risk, screening, transaction monitoring and case management for a mid-size "
    "reporting entity - a single interactive workspace built on synthetic portfolio data.",
)

tab_overview, tab_customers, tab_screening, tab_txn, tab_onboard, tab_team, tab_sim = st.tabs(
    ["Overview", "Customers", "Screening & Cases", "Transactions",
     "Onboarding & Reviews", "Team", "Simulator"]
)

# ==========================================================================
# TAB: OVERVIEW
# ==========================================================================
with tab_overview:
    high_risk = customers[customers["risk_level"].isin(["High", "Critical"])].shape[0]
    pct_hc = high_risk / len(customers) * 100 if len(customers) else 0
    open_hits = screening[screening["status"].isin(["Open", "Escalated", "Under Review"])].shape[0]
    open_cases = cases[~cases["status"].str.contains("Closed")].shape[0]
    pending_smr = cases[cases["status"] == "Pending SMR Lodgement"].shape[0]

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        kpi_card_trend("Total Customers", f"{len(customers):,}",
                        sub=f"{(customers['status']=='Active').sum():,} active")
    with c2:
        hc_delta = f"{'+' if pct_hc >= 15 else '-'}{abs(pct_hc - 15):.1f} pts"
        kpi_card_trend("High / Critical Risk", f"{high_risk:,}", delta=hc_delta,
                        higher_is_better=False, sub="vs 15% target")
    with c3:
        kpi_card_trend("Open Screening Alerts", f"{open_hits:,}", sub=f"{screening.shape[0]} total hits")
    with c4:
        kpi_card_trend("Active Cases", f"{open_cases:,}", sub=f"{cases.shape[0]} total this period")
    with c5:
        kpi_card_trend("Pending SMR Lodgement", f"{pending_smr:,}", sub="within statutory 3-day window")

    section_title("Portfolio Risk Distribution")
    col1, col2 = st.columns([1, 1.15])
    with col1:
        risk_counts = customers["risk_level"].value_counts().reindex(["Low", "Medium", "High", "Critical"]).fillna(0)
        fig = bar2d_chart(list(risk_counts.index), list(risk_counts.values),
                          colors=[RISK_COLOR_MAP[l] for l in risk_counts.index],
                          axis_title="Customers", height=320)
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        industry_series = customers.groupby("industry")["risk_score"].mean().sort_values(ascending=True).tail(8)
        fig2 = bar2d_chart(list(industry_series.index), list(industry_series.values),
                           colors=brass_gradient(list(industry_series.values)), horizontal=True,
                           value_fmt=lambda v: f"{v:.1f}", axis_title="Avg Risk Score", height=320)
        st.plotly_chart(fig2, use_container_width=True)

    section_title("Transaction Volume Trend (Trailing 90 Days)")
    recent = transactions[transactions["txn_date"] >= transactions["txn_date"].max() - pd.Timedelta(days=90)]
    daily = recent.groupby([recent["txn_date"].dt.date, "direction"])["amount"].sum().unstack(fill_value=0).sort_index()
    for col in ("Inbound", "Outbound"):
        if col not in daily.columns:
            daily[col] = 0.0
    date_labels = [d.strftime("%d %b") for d in daily.index]
    fig3 = line_area_chart(date_labels, {"Inbound": daily["Inbound"].tolist(), "Outbound": daily["Outbound"].tolist()},
                           colors={"Inbound": BRASS, "Outbound": TEAL_ACCENT}, y_title="Amount (AUD)", height=300)
    st.plotly_chart(fig3, use_container_width=True)

    section_title("Customer Lifecycle Waterfall")
    total_c = len(customers)
    active_c = int((customers["status"] == "Active").sum())
    hc = int(customers["risk_level"].isin(["High", "Critical"]).sum())
    screened = int(screening["customer_id"].nunique())
    flagged_case = int(cases["customer_id"].nunique())
    escalated = int(cases["status"].isin(
        ["Escalated - Senior Review", "Pending SMR Lodgement", "SMR Lodged", "Post-SMR Monitoring"]).sum())
    smr_lodged = int(cases["status"].isin(["SMR Lodged", "Post-SMR Monitoring"]).sum())
    closed = int(cases["status"].str.contains("Closed").sum())
    wf_labels = ["Total Customers", "Active", "High/Critical", "Screened", "Case Opened", "Escalated", "SMR Lodged", "Closed"]
    wf_values = [total_c, active_c - total_c, hc - active_c, screened - hc, flagged_case - screened,
                 escalated - flagged_case, smr_lodged - escalated, closed - smr_lodged]
    fig4 = waterfall2d_chart(wf_labels, wf_values, height=360,
                             colors={"increasing": BRASS, "decreasing": HIGH, "total": TEAL_ACCENT})
    st.plotly_chart(fig4, use_container_width=True)

# ==========================================================================
# TAB: CUSTOMERS
# ==========================================================================
with tab_customers:
    with st.container(border=True):
        st.markdown('<div class="slicer-label">Filters</div>', unsafe_allow_html=True)
        f1, f2, f3, f4, f5 = st.columns(5)
        with f1:
            industries = st.multiselect("Industry", sorted(customers["industry"].unique()), key="cust_ind")
        with f2:
            countries = st.multiselect("Country", sorted(customers["country"].unique()), key="cust_ctry")
        with f3:
            levels = st.multiselect("Risk Level", ["Low", "Medium", "High", "Critical"], key="cust_lvl")
        with f4:
            statuses = st.multiselect("Status", sorted(customers["status"].unique()), key="cust_status")
        with f5:
            search = st.text_input("Search name / ID", key="cust_search")

    df = customers.copy()
    if industries:
        df = df[df["industry"].isin(industries)]
    if countries:
        df = df[df["country"].isin(countries)]
    if levels:
        df = df[df["risk_level"].isin(levels)]
    if statuses:
        df = df[df["status"].isin(statuses)]
    if search:
        mask = df["name"].str.contains(search, case=False) | df["customer_id"].str.contains(search, case=False)
        df = df[mask]

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        kpi_card("Filtered Customers", f"{len(df):,}")
    with c2:
        kpi_card("Avg Risk Score", f"{df['risk_score'].mean():.1f}" if len(df) else "-")
    with c3:
        kpi_card("High/Critical", f"{int(df['risk_level'].isin(['High', 'Critical']).sum()):,}")
    with c4:
        kpi_card("Dormant/Closed", f"{int(df['status'].isin(['Dormant', 'Closed']).sum()):,}")

    section_title("Risk Score Distribution")
    if df.empty:
        st.info("No customers match the current filters.")
    else:
        bin_edges = list(range(0, 101, 10))
        bin_labels = [f"{a}-{b}" for a, b in zip(bin_edges[:-1], bin_edges[1:])]
        binned = df.copy()
        binned["score_bin"] = pd.cut(binned["risk_score"], bins=bin_edges, labels=bin_labels, include_lowest=True)
        pivot = binned.groupby(["score_bin", "risk_level"], observed=False).size().unstack(fill_value=0)
        for lvl in ["Low", "Medium", "High", "Critical"]:
            if lvl not in pivot.columns:
                pivot[lvl] = 0
        pivot = pivot.reindex(bin_labels).fillna(0)
        fig = grouped_bar2d_chart(bin_labels, {lvl: pivot[lvl].tolist() for lvl in ["Low", "Medium", "High", "Critical"]},
                                  colors=RISK_COLOR_MAP, axis_title="Customers", height=340)
        st.plotly_chart(fig, use_container_width=True)

    section_title(f"Customer Register ({len(df):,} results)")
    show = df.sort_values("risk_score", ascending=False).copy()
    show["Risk"] = show["risk_level"].apply(risk_pill)
    show_disp = show[["customer_id", "name", "customer_type", "industry", "country", "risk_score", "Risk", "status", "onboarding_date"]]
    show_disp = show_disp.rename(columns={"customer_id": "ID", "name": "Name", "customer_type": "Type",
                                          "industry": "Industry", "country": "Country", "risk_score": "Score",
                                          "status": "Status", "onboarding_date": "Onboarded"})
    show_disp["Onboarded"] = pd.to_datetime(show_disp["Onboarded"]).dt.strftime("%d %b %Y")
    st.write(show_disp.to_html(escape=False, index=False), unsafe_allow_html=True)

# ==========================================================================
# TAB: SCREENING & CASES
# ==========================================================================
with tab_screening:
    sub_screen, sub_alerts, sub_cases = st.tabs(["Screening Hits", "Alert Triage", "Case Pipeline"])

    with sub_screen:
        merged = screening.merge(customers[["customer_id", "name", "risk_level", "country"]], on="customer_id", how="left")
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            kpi_card("Total Hits", f"{len(merged):,}")
        with c2:
            kpi_card("Open / Under Review", f"{int(merged['status'].isin(['Open', 'Under Review']).sum()):,}")
        with c3:
            kpi_card("Escalated", f"{int((merged['status'] == 'Escalated').sum()):,}")
        with c4:
            kpi_card("Cleared (False Positive)", f"{int(merged['status'].str.contains('Cleared').sum()):,}")

        section_title("Hits by Type and Status")
        col1, col2 = st.columns(2)
        with col1:
            type_counts = merged["match_type"].value_counts()
            fig = bar2d_chart(list(type_counts.index), list(type_counts.values),
                              colors=[BRASS, TEAL_ACCENT, SAGE][:len(type_counts)], axis_title="Hits", height=300)
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            status_counts = merged["status"].value_counts()
            fig2 = bar2d_chart(list(status_counts.index), list(status_counts.values),
                               colors=brass_gradient(status_counts.values), axis_title="Count", height=300)
            st.plotly_chart(fig2, use_container_width=True)

        section_title(f"Screening Queue ({len(merged):,} results)")
        show = merged.sort_values("match_score", ascending=False).copy()
        show["Risk"] = show["risk_level"].apply(risk_pill)
        disp = show[["screening_id", "customer_id", "name", "match_type", "match_detail", "list_source",
                     "match_score", "Risk", "status", "screened_date"]]
        disp = disp.rename(columns={"screening_id": "Alert ID", "customer_id": "Customer ID", "name": "Name",
                                    "match_type": "Type", "match_detail": "Detail", "list_source": "Source",
                                    "match_score": "Score", "status": "Status", "screened_date": "Screened"})
        disp["Screened"] = pd.to_datetime(disp["Screened"]).dt.strftime("%d %b %Y")
        st.write(disp.head(50).to_html(escape=False, index=False), unsafe_allow_html=True)

    with sub_alerts:
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            kpi_card("Total Alerts", f"{len(alerts):,}")
        with c2:
            kpi_card("New / Untriaged", f"{int((alerts['disposition'] == 'New').sum()):,}")
        with c3:
            kpi_card("Requires Investigation", f"{int((alerts['disposition'] == 'Requires Investigation').sum()):,}")
        with c4:
            kpi_card("Escalated to Case", f"{int((alerts['disposition'] == 'Escalated to Case').sum()):,}")

        section_title("Alerts by Source and Disposition")
        col1, col2 = st.columns(2)
        with col1:
            src_counts = alerts["source"].value_counts()
            fig = bar2d_chart(list(src_counts.index), list(src_counts.values), colors=[BRASS, TEAL_ACCENT],
                              axis_title="Alerts", height=300)
            st.plotly_chart(fig, use_container_width=True)
        with col2:
            disp_counts = alerts["disposition"].value_counts()
            fig2 = donut_chart(disp_counts.index.tolist(), disp_counts.values.tolist(),
                               colors=[HIGH, SAGE, MEDIUM, CRITICAL][:len(disp_counts)],
                               center_label="Total Alerts", center_value=f"{disp_counts.sum():,}", height=300)
            st.plotly_chart(fig2, use_container_width=True)

        section_title(f"Alert Queue ({len(alerts):,} results)")
        show = alerts.sort_values(["disposition", "generated_date"], ascending=[True, False]).copy()
        disp2 = show[["alert_id", "customer_id", "name", "source", "alert_type", "severity", "disposition", "generated_date"]]
        disp2 = disp2.rename(columns={"alert_id": "Alert ID", "customer_id": "Customer ID", "name": "Name",
                                      "source": "Source", "alert_type": "Type", "severity": "Severity",
                                      "disposition": "Disposition", "generated_date": "Generated"})
        disp2["Generated"] = pd.to_datetime(disp2["Generated"]).dt.strftime("%d %b %Y")
        st.write(disp2.head(50).to_html(escape=False, index=False), unsafe_allow_html=True)

    with sub_cases:
        open_c = cases[~cases["status"].str.contains("Closed")]
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            kpi_card("Open Cases", f"{len(open_c):,}")
        with c2:
            kpi_card("Under Investigation", f"{int((cases['status'] == 'Under Investigation').sum()):,}")
        with c3:
            kpi_card("Escalated", f"{int((cases['status'] == 'Escalated - Senior Review').sum()):,}")
        with c4:
            kpi_card("SMR Lodged / Monitoring", f"{int(cases['status'].isin(['SMR Lodged', 'Post-SMR Monitoring']).sum()):,}")

        section_title("Case Pipeline by Status")
        status_counts = cases["status"].value_counts().reindex(CASE_STATUSES).fillna(0)
        pipeline_colors = [CRITICAL if "Restrict" in s else LOW if "Closed" in s
                           else HIGH if ("Pending" in s or "Escalat" in s) else BRASS for s in CASE_STATUSES]
        fig = bar2d_chart(CASE_STATUSES, status_counts.values.tolist(), colors=pipeline_colors,
                          horizontal=True, category_order=CASE_STATUSES, height=340)
        st.plotly_chart(fig, use_container_width=True)

        section_title(f"Case Register ({len(cases):,} results)")
        merged_c = cases.merge(customers[["customer_id", "name", "risk_level"]], on="customer_id", how="left")
        merged_c["Status"] = merged_c["status"].apply(status_pill_html)
        merged_c["Risk"] = merged_c["risk_level"].apply(risk_pill)
        disp3 = merged_c[["case_id", "customer_id", "name", "typology", "priority", "Risk", "Status",
                          "assigned_analyst", "opened_date"]]
        disp3 = disp3.rename(columns={"case_id": "Case ID", "customer_id": "Customer ID", "name": "Name",
                                      "typology": "Typology", "priority": "Priority", "assigned_analyst": "Analyst",
                                      "opened_date": "Opened"})
        disp3["Opened"] = pd.to_datetime(disp3["Opened"]).dt.strftime("%d %b %Y")
        st.write(disp3.to_html(escape=False, index=False), unsafe_allow_html=True)

# ==========================================================================
# TAB: TRANSACTIONS
# ==========================================================================
with tab_txn:
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        kpi_card("Total Transactions", f"{len(transactions):,}")
    with c2:
        kpi_card("Total Inbound", f"${transactions[transactions.direction=='Inbound']['amount'].sum()/1_000_000:.1f}M")
    with c3:
        kpi_card("Total Outbound", f"${transactions[transactions.direction=='Outbound']['amount'].sum()/1_000_000:.1f}M")
    with c4:
        kpi_card("Avg Transaction Size", f"${transactions['amount'].mean():,.0f}")

    sub1, sub2, sub3, sub4 = st.tabs(["Structuring", "Rapid Movement", "High-Risk Wires", "Customer Drill-down"])

    with sub1:
        section_title("Structuring / Smurfing Alerts")
        results = []
        for cid, grp in transactions.groupby("customer_id"):
            f = detect_structuring(grp)
            if f:
                results.append((cid, f))
        kpi_card("Customers Flagged", f"{len(results):,}")
        if results:
            rows = [{"Customer ID": cid, "Name": customers.loc[customers.customer_id == cid, "name"].values[0],
                    "Finding": f.summary, "Severity": f.severity} for cid, f in results]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.success("No structuring patterns detected in the current dataset.")

    with sub2:
        section_title("Rapid Movement of Funds Alerts")
        results = []
        for cid, grp in transactions.groupby("customer_id"):
            f = detect_rapid_movement(grp)
            if f:
                results.append((cid, f))
        kpi_card("Customers Flagged", f"{len(results):,}")
        if results:
            rows = [{"Customer ID": cid, "Name": customers.loc[customers.customer_id == cid, "name"].values[0],
                    "Finding": f.summary, "Severity": f.severity} for cid, f in results]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.success("No rapid movement patterns detected in the current dataset.")

    with sub3:
        section_title("High-Risk Corridor Wire Alerts")
        results = []
        for cid, grp in transactions.groupby("customer_id"):
            f = detect_high_risk_wires(grp, HIGH_RISK_COUNTRIES_DEFAULT)
            if f:
                results.append((cid, f))
        kpi_card("Customers Flagged", f"{len(results):,}")
        if results:
            rows = [{"Customer ID": cid, "Name": customers.loc[customers.customer_id == cid, "name"].values[0],
                    "Finding": f.summary, "Severity": f.severity} for cid, f in results]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

            section_title("Wire Volume by Counterparty Country")
            wires = transactions[(transactions["channel"] == "International Wire")
                                 & (transactions["counterparty_country"].isin(HIGH_RISK_COUNTRIES_DEFAULT))]
            vol = wires.groupby("counterparty_country")["amount"].sum().sort_values(ascending=True)
            fig = bar2d_chart(list(vol.index), list(vol.values), colors=brass_gradient(vol.values),
                              value_fmt=lambda v: f"${v:,.0f}", horizontal=True, axis_title="Total AUD", height=320)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.success("No high-risk corridor wire activity detected in the current dataset.")

    with sub4:
        section_title("Customer Transaction Drill-down")
        options = customers.sort_values("risk_score", ascending=False)
        label_map = {f"{r.customer_id} - {r.name} (risk {r.risk_score})": r.customer_id for r in options.itertuples()}
        choice = st.selectbox("Select a customer", list(label_map.keys()))
        cid = label_map[choice]
        cust_txns = transactions[transactions["customer_id"] == cid].sort_values("txn_date", ascending=False)
        cust = customers[customers["customer_id"] == cid].iloc[0]

        c1, c2, c3, c4 = st.columns(4)
        with c1:
            kpi_card("Total Transactions", f"{len(cust_txns):,}")
        with c2:
            kpi_card("Total Inbound", f"${cust_txns[cust_txns.direction=='Inbound']['amount'].sum():,.0f}")
        with c3:
            kpi_card("Total Outbound", f"${cust_txns[cust_txns.direction=='Outbound']['amount'].sum():,.0f}")
        with c4:
            kpi_card("Risk Score", f"{cust['risk_score']}/100")

        max_amount = cust_txns["amount"].max() if len(cust_txns) else 1
        fig = scatter2d_chart(
            x=cust_txns["txn_date"].tolist(), y=cust_txns["amount"].tolist(),
            color_labels=cust_txns["direction"].tolist(), color_map={"Inbound": BRASS, "Outbound": TEAL_ACCENT},
            size=[8 + 14 * (a / max_amount) for a in cust_txns["amount"]],
            hover_text=[f"{d} - {ch} - {cty} - ${amt:,.0f}" for d, ch, cty, amt in
                       zip(cust_txns["txn_date"].dt.strftime("%d %b %Y"), cust_txns["channel"],
                           cust_txns["counterparty_country"], cust_txns["amount"])],
            x_title="Date", y_title="Amount (AUD)", height=380,
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(
            cust_txns[["txn_date", "amount", "direction", "channel", "counterparty_country", "description"]].head(25),
            use_container_width=True, hide_index=True,
        )

# ==========================================================================
# TAB: ONBOARDING & REVIEWS
# ==========================================================================
with tab_onboard:
    today = pd.Timestamp.today().normalize()
    this_month = customers[customers["onboarding_date"] >= today - pd.Timedelta(days=30)]

    review_interval = {"Low": 24, "Medium": 12, "High": 6, "Critical": 3}
    active = customers[customers["status"] == "Active"].copy()
    active["review_due"] = active.apply(
        lambda r: pd.Timestamp(r["onboarding_date"]) + pd.DateOffset(months=review_interval.get(r["risk_level"], 12)),
        axis=1,
    )
    active["days_until_due"] = (active["review_due"] - today).dt.days
    active["review_state"] = active["days_until_due"].apply(
        lambda d: "Overdue" if d < 0 else "Due within 30 days" if d <= 30 else "Scheduled"
    )

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        kpi_card("New Customers (30d)", f"{len(this_month):,}")
    with c2:
        kpi_card("Overdue for Review", f"{int((active['review_state'] == 'Overdue').sum()):,}")
    with c3:
        kpi_card("Due within 30 Days", f"{int((active['review_state'] == 'Due within 30 days').sum()):,}")
    with c4:
        kpi_card("Active Customers", f"{len(active):,}")

    section_title("Monthly Onboarding Intake (Trailing 12 Months)")
    last_year = customers[customers["onboarding_date"] >= today - pd.Timedelta(days=365)]
    monthly = last_year.groupby(last_year["onboarding_date"].dt.to_period("M")).size()
    month_labels = [str(p) for p in monthly.index]
    fig = line_area_chart(month_labels, {"New Customers": monthly.values.tolist()}, colors={"New Customers": BRASS},
                          y_title="Customers", height=280)
    st.plotly_chart(fig, use_container_width=True)

    section_title("Review Schedule by Risk Level")
    risk_order = ["Low", "Medium", "High", "Critical"]
    review_states = ["Overdue", "Due within 30 days", "Scheduled"]
    pivot = active.groupby(["risk_level", "review_state"], observed=False).size().unstack(fill_value=0)
    for state in review_states:
        if state not in pivot.columns:
            pivot[state] = 0
    pivot = pivot.reindex(risk_order).fillna(0)
    fig2 = grouped_bar2d_chart(risk_order, {s: pivot[s].tolist() for s in review_states},
                               colors={"Overdue": CRITICAL, "Due within 30 days": HIGH, "Scheduled": SAGE},
                               axis_title="Customers", height=340)
    st.plotly_chart(fig2, use_container_width=True)

    section_title("Upcoming Reviews")
    show = active.sort_values("days_until_due").head(30).copy()
    state_pill_map = {
        "Overdue": '<span class="pill pill-critical">Overdue</span>',
        "Due within 30 days": '<span class="pill pill-high">Due within 30 days</span>',
        "Scheduled": '<span class="pill pill-low">Scheduled</span>',
    }
    show["State"] = show["review_state"].map(state_pill_map)
    show["Risk"] = show["risk_level"].apply(risk_pill)
    disp = show[["customer_id", "name", "Risk", "review_due", "State"]].rename(
        columns={"customer_id": "ID", "name": "Name", "review_due": "Review Due"})
    disp["Review Due"] = pd.to_datetime(disp["Review Due"]).dt.strftime("%d %b %Y")
    st.write(disp.to_html(escape=False, index=False), unsafe_allow_html=True)

# ==========================================================================
# TAB: TEAM
# ==========================================================================
with tab_team:
    load_by_analyst = cases["assigned_analyst"].value_counts()
    open_c = cases[~cases["status"].str.contains("Closed")]
    avg_age = (pd.Timestamp.today().normalize() - pd.to_datetime(open_c["opened_date"])).dt.days.mean() if len(open_c) else 0

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        kpi_card("Analysts on Roster", f"{load_by_analyst.shape[0]:,}")
    with c2:
        kpi_card("Open Cases", f"{len(open_c):,}")
    with c3:
        kpi_card("Avg Open Case Age", f"{avg_age:.0f} days" if len(open_c) else "-")
    with c4:
        kpi_card("Audit Log Entries", f"{len(audit_log):,}")

    section_title("Case Load by Analyst")
    if load_by_analyst.empty:
        st.info("No cases currently assigned.")
    else:
        fig = bar2d_chart(load_by_analyst.index.tolist(), load_by_analyst.values.tolist(),
                          colors=brass_gradient(load_by_analyst.values.tolist()), horizontal=True,
                          axis_title="Cases", height=320)
        st.plotly_chart(fig, use_container_width=True)

    section_title("Audit Activity by Entity Type")
    counts = audit_log["entity_type"].value_counts()
    fig2 = bar2d_chart(list(counts.index), list(counts.values), colors=brass_gradient(counts.values),
                       axis_title="Log Entries", height=300)
    st.plotly_chart(fig2, use_container_width=True)

    section_title("Recent Audit Log")
    recent_log = audit_log.sort_values("timestamp", ascending=False).head(20).copy()
    recent_log["timestamp"] = pd.to_datetime(recent_log["timestamp"]).dt.strftime("%d %b %Y %H:%M")
    disp = recent_log.rename(columns={"timestamp": "Timestamp", "actor": "Actor", "action": "Action",
                                      "entity_type": "Entity Type", "entity_id": "Entity ID", "detail": "Detail"})
    st.dataframe(disp[["Timestamp", "Actor", "Action", "Entity Type", "Entity ID", "Detail"]],
                use_container_width=True, hide_index=True)

# ==========================================================================
# TAB: SIMULATOR
# ==========================================================================
with tab_sim:
    st.caption(
        "Adjust policy thresholds below to see the downstream impact on the portfolio in real time - "
        "the same what-if exercise a Compliance Officer would run before recommending a policy change."
    )
    with st.container(border=True):
        st.markdown('<div class="slicer-label">Scenario Controls</div>', unsafe_allow_html=True)
        s1, s2, s3 = st.columns(3)
        with s1:
            risk_threshold = st.slider("High-risk score threshold", 30, 90, 60, step=5)
        with s2:
            smr_target_days = st.slider("SMR lodgement target (days)", 1, 10, 3)
        with s3:
            screening_target_pct = st.slider("Screening resolution target (%)", 50, 95, 80, step=5)

    baseline_flagged = int((customers["risk_score"] >= 60).sum())
    sim_flagged = int((customers["risk_score"] >= risk_threshold).sum())
    delta_flagged = sim_flagged - baseline_flagged
    sim_pct = sim_flagged / len(customers) * 100 if len(customers) else 0

    lodged = cases[cases["smr_submitted_date"].notna()].copy()
    if not lodged.empty:
        lodged["days_to_lodge"] = (pd.to_datetime(lodged["smr_submitted_date"]) - pd.to_datetime(lodged["opened_date"])).dt.days
        pct_within_target = (lodged["days_to_lodge"] <= smr_target_days).sum() / len(lodged) * 100
    else:
        pct_within_target = 0

    total_screening = len(screening)
    resolved = int(screening["status"].isin(["Cleared - False Positive", "Escalated"]).sum())
    pct_resolved = resolved / total_screening * 100 if total_screening else 0

    c1, c2, c3 = st.columns(3)
    with c1:
        kpi_card_trend("Customers Flagged at Threshold", f"{sim_flagged:,}",
                       delta=f"{'+' if delta_flagged >= 0 else ''}{delta_flagged:,}",
                       higher_is_better=False, sub=f"vs {baseline_flagged:,} at the standard 60 cutoff")
    with c2:
        kpi_card("% of Portfolio Flagged", f"{sim_pct:.1f}%", sub=f"at score >= {risk_threshold}")
    with c3:
        kpi_card("SMRs Meeting Target", f"{pct_within_target:.0f}%", sub=f"of {len(lodged):,} lodged, within {smr_target_days}-day target")

    section_title("Impact on Compliance Health Targets")
    g1, g2, g3 = st.columns(3)
    with g1:
        st.markdown('<div class="bi-visual-label">% High-Risk at New Threshold</div>'
                    f'<div class="bi-visual-value">{sim_pct:.1f}%</div>', unsafe_allow_html=True)
        st.plotly_chart(bullet_kpi_chart(sim_pct, 15, BRASS, label="High-Risk %"), use_container_width=True)
    with g2:
        st.markdown('<div class="bi-visual-label">% SMRs Within New Target</div>'
                    f'<div class="bi-visual-value">{pct_within_target:.0f}%</div>', unsafe_allow_html=True)
        color = SAGE if pct_within_target >= 80 else HIGH
        st.plotly_chart(bullet_kpi_chart(pct_within_target, 80, color, label="SMR Timeliness"), use_container_width=True)
    with g3:
        st.markdown('<div class="bi-visual-label">% Screening Resolved vs New Target</div>'
                    f'<div class="bi-visual-value">{pct_resolved:.1f}%</div>', unsafe_allow_html=True)
        color2 = SAGE if pct_resolved >= screening_target_pct else HIGH
        st.plotly_chart(bullet_kpi_chart(pct_resolved, screening_target_pct, color2, label="Screening Resolved"),
                        use_container_width=True)

    section_title("Risk Score Distribution vs Threshold")
    bin_edges = list(range(0, 101, 10))
    bin_labels = [f"{a}-{b}" for a, b in zip(bin_edges[:-1], bin_edges[1:])]
    binned = customers.copy()
    binned["score_bin"] = pd.cut(binned["risk_score"], bins=bin_edges, labels=bin_labels, include_lowest=True)
    counts = binned["score_bin"].value_counts().reindex(bin_labels).fillna(0)
    bin_colors = [CRITICAL if a >= risk_threshold else DUSTY_BLUE for a, b in zip(bin_edges[:-1], bin_edges[1:])]
    fig = bar2d_chart(bin_labels, counts.values.tolist(), colors=bin_colors, category_order=bin_labels,
                      axis_title="Customers", height=320)
    st.plotly_chart(fig, use_container_width=True)
    st.caption("Bins at or above the selected threshold are highlighted - this is the population that would be "
              "reclassified if the cutoff moved.")

st.markdown(
    f'<div class="bi-footer">Synthetic demo portfolio - data as of '
    f'{transactions["txn_date"].max().strftime("%d %b %Y")}.</div>',
    unsafe_allow_html=True,
)
