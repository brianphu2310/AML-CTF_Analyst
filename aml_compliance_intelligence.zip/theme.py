"""
theme.py
Visual theme for the rebuilt AML Compliance Intelligence app.

Palette lifted from the reference law-firm site screenshot: a near-black
charcoal-olive body, a slightly lighter charcoal for cards/panels, warm
cream text, and a single restrained brass accent - no bright "fintech"
colors, no icons or emoji. Headlines use an italic serif (Playfair
Display) the way the reference site sets "Our People"; nav and labels
use a tracked-out uppercase sans (Inter).

This is a from-scratch rebuild for the single-file, top-tab-nav app
(app.py) - it intentionally does not carry over the old cream/teal
multipage theme.
"""

import math
import textwrap
import streamlit as st
import plotly.graph_objects as go

# ==========================================================================
# PALETTE
# ==========================================================================
BG_BASE = "#1C1E18"        # page canvas
BG_PANEL = "#262920"       # card / panel surface
BG_PANEL_2 = "#2E3128"     # slightly raised surface (hover, header band)
BG_TOPBAR = "#20221C"      # nav bar

BORDER = "rgba(243,241,234,0.10)"
BORDER_STRONG = "rgba(243,241,234,0.18)"

TEXT_CREAM = "#F3F1EA"     # headings, primary text
TEXT_MUTED = "#B8BAAE"     # secondary text
TEXT_FAINT = "#83867A"     # tertiary / captions

BRASS = "#C9A227"          # single accent - active states, targets, ticks
BRASS_SOFT = "#8E7A3C"

TEAL_ACCENT = "#5FA89F"    # secondary series color
SAGE = "#7FAE86"
DUSTY_BLUE = "#6E8FA6"
ROSE = "#B97066"

LOW = "#6FA98B"
MEDIUM = "#C9A227"
HIGH = "#D98A4B"
CRITICAL = "#C0605A"
INFO = "#6E8FA6"

RISK_COLOR_MAP = {"Low": LOW, "Medium": MEDIUM, "High": HIGH, "Critical": CRITICAL}
CHART_SEQ = [BRASS, TEAL_ACCENT, SAGE, DUSTY_BLUE, ROSE, HIGH, CRITICAL, "#9A9C86"]
CHART_GRID = "rgba(243,241,234,0.08)"

# Backwards-compat aliases (kept short since this is a fresh build)
CARD_BG = BG_PANEL
CARD_BORDER = BORDER

FONT_SANS = "'Inter', -apple-system, sans-serif"
FONT_SERIF = "'Playfair Display', 'Source Serif 4', Georgia, serif"


# ==========================================================================
# CSS
# ==========================================================================
def inject_css():
    st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;1,500;1,600&family=Inter:wght@400;500;600;700&display=swap');

html, body, [class*="css"] {{
    font-family: {FONT_SANS};
}}
.stApp {{
    background: {BG_BASE};
    color: {TEXT_CREAM};
}}
#MainMenu, header[data-testid="stHeader"], footer {{ visibility: hidden; height: 0; }}
.block-container {{
    padding-top: 1rem; padding-bottom: 2rem;
    max-width: 1360px;
}}
h1, h2, h3, h4 {{ color: {TEXT_CREAM}; font-family: {FONT_SANS}; }}
p, span, label, div {{ color: {TEXT_CREAM}; }}
::selection {{ background: {BRASS}; color: {BG_BASE}; }}

/* ---------------------------------------------------------------- HERO */
.hero-kicker {{
    font-size: 0.7rem; letter-spacing: 0.22em; text-transform: uppercase;
    color: {BRASS}; font-weight: 600; margin-bottom: 0.3rem;
}}
.hero-title {{
    font-family: {FONT_SERIF}; font-style: italic; font-weight: 500;
    font-size: 2.4rem; color: {TEXT_CREAM}; line-height: 1.08; margin-bottom: 0.35rem;
}}
.hero-sub {{
    font-size: 0.92rem; color: {TEXT_MUTED}; max-width: 760px; line-height: 1.5;
}}
.hero-wrap {{
    padding: 1.6rem 0 1.3rem 0; border-bottom: 1px solid {BORDER}; margin-bottom: 1.1rem;
}}

/* ---------------------------------------------------------------- TAB NAV BAR */
div[data-testid="stTabs"] {{
    margin-bottom: 1.3rem;
}}
div[data-testid="stTabs"] div[role="tablist"] {{
    background: {BG_TOPBAR};
    border: 1px solid {BORDER};
    border-radius: 4px;
    gap: 0; padding: 0 0.4rem;
    box-shadow: 0 0 0 100vmax {BG_TOPBAR};
    clip-path: inset(0 -100vmax 0 -100vmax);
}}
button[data-baseweb="tab"] {{
    height: 3rem;
    font-family: {FONT_SANS}; font-size: 0.72rem; font-weight: 600;
    letter-spacing: 0.14em; text-transform: uppercase;
    color: {TEXT_MUTED} !important;
    background: transparent !important;
    border: none !important;
    margin: 0 0.3rem;
}}
button[data-baseweb="tab"]:hover {{ color: {TEXT_CREAM} !important; }}
button[data-baseweb="tab"][aria-selected="true"] {{ color: {TEXT_CREAM} !important; }}
div[data-testid="stTabs"] div[data-baseweb="tab-highlight"] {{
    background-color: {BRASS} !important; height: 2px !important;
}}
div[data-testid="stTabs"] div[data-baseweb="tab-border"] {{ display: none; }}

/* ---------------------------------------------------------------- CARDS / KPI */
.kpi-card {{
    background: {BG_PANEL};
    border: 1px solid {BORDER};
    border-top: 2px solid {BRASS};
    border-radius: 4px;
    padding: 0.95rem 1.1rem;
    height: 100%;
    transition: border-color 0.15s ease, transform 0.15s ease;
}}
.kpi-card:hover {{ border-color: {BORDER_STRONG}; transform: translateY(-2px); }}
.kpi-label {{
    font-size: 0.66rem; text-transform: uppercase; letter-spacing: 0.1em;
    color: {TEXT_FAINT}; font-weight: 600; margin-bottom: 0.35rem;
}}
.kpi-value {{
    font-family: {FONT_SERIF}; font-weight: 600; font-size: 1.55rem;
    color: {TEXT_CREAM}; line-height: 1.1; margin-bottom: 0.3rem;
}}
.kpi-sub {{ font-size: 0.74rem; color: {TEXT_MUTED}; }}
.kpi-trend-up {{ color: {SAGE}; font-weight: 700; }}
.kpi-trend-down {{ color: {HIGH}; font-weight: 700; }}
.bi-kpi-row {{ display: flex; align-items: baseline; gap: 0.4rem; font-size: 0.76rem; }}

.section-title {{
    font-family: {FONT_SERIF}; font-style: italic; font-weight: 500;
    font-size: 1.15rem; color: {TEXT_CREAM}; margin: 1.5rem 0 0.5rem 0;
}}
.bi-visual-label {{
    font-size: 0.68rem; font-weight: 700; text-transform: uppercase;
    letter-spacing: 0.08em; color: {TEXT_FAINT}; margin-bottom: 0.1rem;
}}
.bi-visual-value {{
    font-family: {FONT_SERIF}; font-weight: 600; font-size: 1.15rem;
    color: {TEXT_CREAM}; margin-bottom: 0.2rem;
}}

/* ---------------------------------------------------------------- PLOTLY CARD FRAME */
div[data-testid="stPlotlyChart"] {{
    background: {BG_PANEL};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 0.35rem 0.4rem 0.1rem 0.4rem;
    transition: border-color 0.15s ease;
}}
div[data-testid="stPlotlyChart"]:hover {{ border-color: {BORDER_STRONG}; }}

/* ---------------------------------------------------------------- PANEL / SLICER */
div[data-testid="stVerticalBlockBorderWrapper"] {{ border-radius: 4px !important; }}
.slicer-label {{
    font-size: 0.64rem; text-transform: uppercase; letter-spacing: 0.12em;
    color: {TEXT_FAINT}; font-weight: 700; margin-bottom: 0.4rem;
}}

/* ---------------------------------------------------------------- TABLES */
table {{
    border-collapse: separate; border-spacing: 0; width: 100%;
    font-size: 0.82rem; background: {BG_PANEL};
    border: 1px solid {BORDER}; border-radius: 4px; overflow: hidden;
}}
table thead th {{
    background: {BG_TOPBAR}; color: {TEXT_MUTED};
    text-align: left; padding: 0.55rem 0.7rem;
    font-weight: 600; font-size: 0.68rem;
    text-transform: uppercase; letter-spacing: 0.05em;
    border-bottom: 1px solid {BORDER};
}}
table tbody td {{ padding: 0.48rem 0.7rem; border-bottom: 1px solid {BORDER}; color: {TEXT_CREAM}; }}
table tbody tr:last-child td {{ border-bottom: none; }}
table tbody tr:nth-child(even) {{ background: {BG_PANEL_2}; }}
table tbody tr:hover td {{ background: rgba(201,162,39,0.07); }}
.bi-matrix-wrap {{ overflow-x: auto; }}
.bi-matrix-wrap td, .bi-matrix-wrap th {{ text-align: right; }}
.bi-matrix-wrap td:first-child, .bi-matrix-wrap th:first-child {{ text-align: left; }}

/* ---------------------------------------------------------------- PILLS */
.pill {{
    display: inline-block; padding: 0.15rem 0.55rem; border-radius: 3px;
    font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;
}}
.pill-low {{ background: rgba(111,169,139,0.16); color: {LOW}; }}
.pill-medium {{ background: rgba(201,162,39,0.16); color: {MEDIUM}; }}
.pill-high {{ background: rgba(217,138,75,0.16); color: {HIGH}; }}
.pill-critical {{ background: rgba(192,96,90,0.18); color: {CRITICAL}; }}
.pill-info {{ background: rgba(110,143,166,0.16); color: {INFO}; }}

/* ---------------------------------------------------------------- WIDGETS */
div[data-testid="stMetric"] {{ display: none; }}
.stRadio > div {{ gap: 0.2rem; }}
div[data-baseweb="select"] > div {{
    background: {BG_PANEL}; border-color: {BORDER}; color: {TEXT_CREAM};
}}
.stSlider [data-baseweb="slider"] div[role="slider"] {{ background-color: {BRASS} !important; }}
div[data-testid="stAlert"] {{ border-radius: 4px; border-left: 3px solid {BRASS}; background: {BG_PANEL}; }}
hr {{ border-color: {BORDER}; margin: 1.4rem 0; }}
.bi-footer {{
    color: {TEXT_FAINT}; font-size: 0.72rem; text-align: right;
    margin-top: 1rem; padding-top: 0.6rem; border-top: 1px solid {BORDER};
}}
</style>
""", unsafe_allow_html=True)


# ==========================================================================
# LAYOUT / TEXT HELPERS
# ==========================================================================
def hero(kicker: str, title: str, subtitle: str = ""):
    html = f"""<div class="hero-wrap">
<div class="hero-kicker">{kicker}</div>
<div class="hero-title">{title}</div>
<div class="hero-sub">{subtitle}</div>
</div>"""
    st.markdown(textwrap.dedent(html), unsafe_allow_html=True)


def section_title(text: str):
    st.markdown(f'<div class="section-title">{text}</div>', unsafe_allow_html=True)


def kpi_card(label: str, value: str, sub: str = ""):
    html = f"""<div class="kpi-card">
<div class="kpi-label">{label}</div>
<div class="kpi-value">{value}</div>
<div class="kpi-sub">{sub}</div>
</div>"""
    st.markdown(textwrap.dedent(html), unsafe_allow_html=True)


def kpi_card_trend(label: str, value: str, delta: str = "", sub: str = "", higher_is_better: bool = True):
    trend_html = ""
    if delta:
        is_up = delta.strip().startswith("+")
        good = is_up if higher_is_better else (not is_up)
        cls = "kpi-trend-up" if good else "kpi-trend-down"  # class name = good/bad, not arrow direction
        arrow = "\u25B2" if is_up else "\u25BC"
        trend_html = f'<span class="{cls}">{arrow} {delta.lstrip("+-")}</span>'
    html = f"""<div class="kpi-card">
<div class="kpi-label">{label}</div>
<div class="kpi-value">{value}</div>
<div class="bi-kpi-row">{trend_html}<span style="color:{TEXT_MUTED};">{sub}</span></div>
</div>"""
    st.markdown(textwrap.dedent(html), unsafe_allow_html=True)


def risk_pill(level: str) -> str:
    cls = {"Low": "pill-low", "Medium": "pill-medium", "High": "pill-high", "Critical": "pill-critical"}.get(level, "pill-info")
    return f'<span class="pill {cls}">{level}</span>'


def status_pill_html(status: str) -> str:
    s = status.lower()
    if "closed" in s and "restrict" in s:
        cls = "pill-critical"
    elif "closed" in s:
        cls = "pill-low"
    elif "smr lodged" in s or "post-smr" in s:
        cls = "pill-info"
    elif "pending" in s or "escalat" in s:
        cls = "pill-high"
    elif "investigation" in s:
        cls = "pill-medium"
    else:
        cls = "pill-info"
    return f'<span class="pill {cls}">{status}</span>'


def matrix_table_html(row_labels, col_labels, values, row_header="", value_fmt=None, color=None):
    color = color or BRASS
    flat = [v for row in values for v in row]
    vmax = max(flat) if flat else 0
    vmax = vmax or 1

    def fmt(v):
        return value_fmt(v) if value_fmt else f"{v:,.0f}"

    thead = f"<th>{row_header}</th>" + "".join(f"<th>{c}</th>" for c in col_labels)
    body_rows = []
    for r_label, row in zip(row_labels, values):
        cells = []
        for v in row:
            pct = 0 if v <= 0 else max(6, round(v / vmax * 100))
            cells.append(
                f'<td><div style="position:relative;height:1.4em;">'
                f'<div style="position:absolute;top:1px;bottom:1px;right:0;width:{pct}%;'
                f'background:{color}30;border-radius:2px;"></div>'
                f'<span style="position:relative;font-weight:600;">{fmt(v)}</span></div></td>'
            )
        body_rows.append(f"<tr><td style=\"font-weight:600;\">{r_label}</td>{''.join(cells)}</tr>")

    return (
        '<div class="bi-matrix-wrap"><table><thead><tr>' + thead + "</tr></thead>"
        "<tbody>" + "".join(body_rows) + "</tbody></table></div>"
    )


# ==========================================================================
# GRADIENTS
# ==========================================================================
def _hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def interpolate_color(c1, c2, t):
    r1, g1, b1 = _hex_to_rgb(c1)
    r2, g2, b2 = _hex_to_rgb(c2)
    r = round(r1 + (r2 - r1) * t)
    g = round(g1 + (g2 - g1) * t)
    b = round(b1 + (b2 - b1) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


def _rank_positions(values):
    values = list(values)
    n = len(values)
    if n == 0:
        return []
    if n == 1:
        return [1.0]
    order = sorted(range(n), key=lambda i: values[i])
    positions = [0.0] * n
    for rank, idx in enumerate(order):
        positions[idx] = rank / (n - 1)
    return positions


def brass_gradient(values, dark: str = BRASS_SOFT, light: str = "#4A4630"):
    positions = _rank_positions(values)
    return [interpolate_color(light, dark, p) for p in positions]


# kept for drop-in compatibility with chart calls written against the old theme
teal_gradient = brass_gradient


def _rgba(hex_color: str, alpha: float) -> str:
    r, g, b = _hex_to_rgb(hex_color)
    return f"rgba({r},{g},{b},{alpha})"


# ==========================================================================
# FLAT 2D CHART ENGINE (dark)
# ==========================================================================
def _flat_layout(height, legend=False, title=""):
    layout = dict(
        template="plotly_dark",
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, sans-serif", color=TEXT_CREAM, size=11),
        margin=dict(t=30 if title else (26 if legend else 6), b=6, l=6, r=10),
        height=height,
        bargap=0.32,
        xaxis=dict(gridcolor=CHART_GRID, zeroline=False, linecolor=BORDER,
                   tickfont=dict(color=TEXT_MUTED, size=10.5),
                   title_font=dict(color=TEXT_MUTED, size=10.5)),
        yaxis=dict(gridcolor=CHART_GRID, zeroline=False, linecolor=BORDER,
                   tickfont=dict(color=TEXT_MUTED, size=10.5),
                   title_font=dict(color=TEXT_MUTED, size=10.5)),
        hoverlabel=dict(bgcolor=BG_PANEL_2, bordercolor=BORDER,
                        font=dict(family="Inter, sans-serif", color=TEXT_CREAM, size=12)),
        showlegend=legend,
    )
    if legend:
        layout["legend"] = dict(orientation="h", yanchor="bottom", y=1.0, xanchor="left", x=0,
                                 font=dict(color=TEXT_CREAM, size=10.5))
    if title:
        layout["title"] = dict(text=title, font=dict(family=FONT_SERIF, size=14, color=TEXT_CREAM),
                                x=0.0, xanchor="left", y=0.97)
    return layout


def bar2d_chart(categories, values, colors=None, horizontal=False, height=300,
                 value_fmt=None, axis_title="", category_order=None):
    categories = list(categories)
    values = [float(v) for v in values]
    if colors is None:
        colors = brass_gradient(values)
    if isinstance(colors, str):
        colors = [colors] * len(values)
    text = [value_fmt(v) if value_fmt else f"{v:,.0f}" for v in values]

    bar = go.Bar(
        x=values if horizontal else categories,
        y=categories if horizontal else values,
        orientation="h" if horizontal else "v",
        marker=dict(color=colors, line=dict(width=0.6, color="rgba(0,0,0,0.25)")),
        text=text, textposition="outside", cliponaxis=False,
        textfont=dict(color=TEXT_CREAM, size=10.5, family="Inter, sans-serif"),
        hovertemplate=("%{y}: %{x:,.0f}<extra></extra>" if horizontal else "%{x}: %{y:,.0f}<extra></extra>"),
    )
    fig = go.Figure(data=[bar])
    layout = _flat_layout(height)
    if horizontal:
        layout["yaxis"].update(showgrid=False)
        if category_order:
            layout["yaxis"].update(categoryorder="array", categoryarray=list(reversed(category_order)))
        else:
            layout["yaxis"].update(categoryorder="total ascending")
        layout["xaxis"].update(showgrid=True, title=dict(text=axis_title))
    else:
        layout["xaxis"].update(showgrid=False)
        if category_order:
            layout["xaxis"].update(categoryorder="array", categoryarray=category_order)
        layout["yaxis"].update(showgrid=True, title=dict(text=axis_title))
    fig.update_layout(**layout)
    return fig


def grouped_bar2d_chart(categories, series: dict, colors: dict = None, height=320,
                         value_fmt=None, horizontal=False, axis_title=""):
    categories = list(categories)
    names = list(series.keys())
    colors = colors or {}
    traces = []
    for i, name in enumerate(names):
        vals = [float(v) for v in series[name]]
        col = colors.get(name, CHART_SEQ[i % len(CHART_SEQ)])
        hover = (f"{name} - " + "%{y}: %{x:,.0f}<extra></extra>") if horizontal else \
                (f"{name} - " + "%{x}: %{y:,.0f}<extra></extra>")
        traces.append(go.Bar(
            x=vals if horizontal else categories,
            y=categories if horizontal else vals,
            orientation="h" if horizontal else "v",
            name=name, marker=dict(color=col, line=dict(width=0.6, color="rgba(0,0,0,0.25)")),
            hovertemplate=hover,
        ))
    fig = go.Figure(data=traces)
    layout = _flat_layout(height, legend=True)
    layout["barmode"] = "group"
    if horizontal:
        layout["yaxis"].update(showgrid=False, categoryorder="array", categoryarray=list(reversed(categories)))
        layout["xaxis"].update(showgrid=True, title=dict(text=axis_title))
    else:
        layout["xaxis"].update(showgrid=False, categoryorder="array", categoryarray=categories)
        layout["yaxis"].update(showgrid=True, title=dict(text=axis_title))
    fig.update_layout(**layout)
    return fig


def line_area_chart(x_labels, series: dict, colors: dict = None, height=300, y_title="", area=True):
    names = list(series.keys())
    colors = colors or {}
    traces = []
    for i, name in enumerate(names):
        vals = list(series[name])
        col = colors.get(name, CHART_SEQ[i % len(CHART_SEQ)])
        traces.append(go.Scatter(
            x=list(x_labels), y=vals, mode="lines", name=name,
            line=dict(color=col, width=2.2, shape="spline", smoothing=0.3),
            fill="tozeroy" if area else None,
            fillcolor=_rgba(col, 0.14) if area else None,
            hovertemplate=f"{name} - " + "%{x}: %{y:,.0f}<extra></extra>",
        ))
    fig = go.Figure(data=traces)
    layout = _flat_layout(height, legend=len(names) > 1)
    layout["xaxis"].update(showgrid=False)
    layout["yaxis"].update(showgrid=True, title=dict(text=y_title))
    fig.update_layout(**layout)
    fig.update_layout(hovermode="x unified")
    return fig


def donut_chart(labels, values, colors=None, height=280, center_label="", center_value=""):
    labels = list(labels)
    values = [float(v) for v in values]
    if colors is None:
        colors = CHART_SEQ[:len(labels)] if len(labels) <= len(CHART_SEQ) else brass_gradient(values)

    fig = go.Figure(data=[go.Pie(
        labels=labels, values=values, hole=0.64, sort=False,
        marker=dict(colors=colors, line=dict(color=BG_PANEL, width=2)),
        textinfo="percent", textfont=dict(size=10.5, color=TEXT_CREAM, family="Inter, sans-serif"),
        hovertemplate="%{label}: %{value:,.0f} (%{percent})<extra></extra>",
    )])

    annotations = []
    if center_value:
        annotations.append(dict(text=f"<b>{center_value}</b>", x=0.5, y=0.56, showarrow=False,
                                 font=dict(size=19, color=TEXT_CREAM, family=FONT_SERIF)))
    if center_label:
        annotations.append(dict(text=center_label, x=0.5, y=0.40, showarrow=False,
                                 font=dict(size=9.5, color=TEXT_FAINT, family="Inter, sans-serif")))

    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", height=height,
        margin=dict(t=6, b=6, l=6, r=6), annotations=annotations,
        font=dict(family="Inter, sans-serif"),
        legend=dict(orientation="v", x=1.0, y=0.5, xanchor="left", yanchor="middle",
                    font=dict(color=TEXT_CREAM, size=10)),
    )
    return fig


def bullet_kpi_chart(value, target, color, max_value=100, height=54, suffix="%", label="", higher_is_better=True):
    span = max(max_value, value, target) * 1.02 or 1
    fig = go.Figure()
    fig.add_trace(go.Bar(x=[span], y=[""], orientation="h", width=0.62,
                          marker=dict(color="rgba(243,241,234,0.09)"), hoverinfo="skip", showlegend=False))
    fig.add_trace(go.Bar(x=[value], y=[""], orientation="h", width=0.62, marker=dict(color=color),
                          hovertemplate=f"{label}: {value:.1f}{suffix} (target {target:.0f}{suffix})<extra></extra>",
                          showlegend=False))
    fig.add_shape(type="line", x0=target, x1=target, xref="x", y0=-0.42, y1=0.42, yref="y",
                  line=dict(color=TEXT_CREAM, width=2))
    fig.update_layout(
        barmode="overlay", template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        height=height, margin=dict(t=2, b=2, l=2, r=2),
        xaxis=dict(range=[0, span], visible=False), yaxis=dict(visible=False), showlegend=False,
    )
    return fig


def waterfall2d_chart(labels, values, height=360, colors=None):
    colors = colors or {}
    inc_color = colors.get("increasing", BRASS)
    dec_color = colors.get("decreasing", HIGH)
    tot_color = colors.get("total", TEAL_ACCENT)
    measures = ["absolute"] + ["relative"] * (len(values) - 1)
    text = [f"{values[0]:,.0f}"] + [f"{v:+,.0f}" for v in values[1:]]

    fig = go.Figure(go.Waterfall(
        x=list(labels), y=list(values), measure=measures,
        text=text, textposition="outside",
        textfont=dict(color=TEXT_CREAM, size=11, family="Inter, sans-serif"),
        increasing=dict(marker=dict(color=inc_color)),
        decreasing=dict(marker=dict(color=dec_color)),
        totals=dict(marker=dict(color=tot_color)),
        connector=dict(line=dict(color=BORDER, width=1.2)),
    ))
    layout = _flat_layout(height)
    layout["xaxis"].update(showgrid=False)
    layout["yaxis"].update(showgrid=True)
    fig.update_layout(**layout)
    fig.update_layout(showlegend=False)
    return fig


def scatter2d_chart(x, y, color_labels=None, color_map=None, size=None, hover_text=None,
                     x_title="", y_title="", height=380):
    color_labels = list(color_labels) if color_labels is not None else ["All"] * len(x)
    color_map = color_map or {}
    groups = list(dict.fromkeys(color_labels))
    traces = []
    for g_idx, g in enumerate(groups):
        idxs = [i for i, lab in enumerate(color_labels) if lab == g]
        col = color_map.get(g, CHART_SEQ[g_idx % len(CHART_SEQ)])
        marker_size = [size[i] for i in idxs] if size is not None else 8
        traces.append(go.Scatter(
            x=[x[i] for i in idxs], y=[y[i] for i in idxs], mode="markers", name=str(g),
            marker=dict(size=marker_size, color=col, opacity=0.82, line=dict(width=0.6, color=BG_PANEL)),
            text=[hover_text[i] for i in idxs] if hover_text is not None else None,
            hoverinfo="text" if hover_text is not None else "x+y",
        ))
    fig = go.Figure(data=traces)
    layout = _flat_layout(height, legend=len(groups) > 1)
    layout["xaxis"].update(title=dict(text=x_title), showgrid=True)
    layout["yaxis"].update(title=dict(text=y_title), showgrid=True)
    fig.update_layout(**layout)
    return fig


def network2d_chart(center_label, center_kind, nodes, color_map, height=440):
    n = max(len(nodes), 1)
    radius = 1.0
    edge_x, edge_y = [], []
    node_x, node_y = [0.0], [0.0]
    node_color = [color_map.get(center_kind, BRASS)]
    node_size = [34]
    label_text = [center_label]
    hover_text = [center_label]

    for idx, node in enumerate(nodes):
        angle = 2 * math.pi * idx / n - math.pi / 2
        x, y = radius * math.cos(angle), radius * math.sin(angle)
        weight = float(node.get("weight", 0) or 0)
        node_x.append(x)
        node_y.append(y)
        hover_text.append(f"{node['label']} ({weight:.0f}%)" if weight else node["label"])
        node_color.append(color_map.get(node.get("kind"), TEXT_MUTED))
        node_size.append(16 + weight * 0.22)
        label_text.append(node["label"] + (f" ({weight:.0f}%)" if weight else ""))
        edge_x += [0, x, None]
        edge_y += [0, y, None]

    edge_trace = go.Scatter(x=edge_x, y=edge_y, mode="lines",
                             line=dict(color=BORDER_STRONG, width=1.6), hoverinfo="skip", showlegend=False)
    node_trace = go.Scatter(
        x=node_x, y=node_y, mode="markers+text", text=label_text, textposition="bottom center",
        textfont=dict(color=TEXT_CREAM, size=10.5, family="Inter, sans-serif"),
        marker=dict(size=node_size, color=node_color, opacity=0.95, line=dict(width=1.5, color=BG_PANEL)),
        hovertext=hover_text, hoverinfo="text", showlegend=False,
    )
    fig = go.Figure(data=[edge_trace, node_trace])
    layout = _flat_layout(height)
    layout["xaxis"].update(visible=False, showgrid=False, range=[-1.6, 1.6])
    layout["yaxis"].update(visible=False, showgrid=False, range=[-1.6, 1.6], scaleanchor="x", scaleratio=1)
    fig.update_layout(**layout)
    return fig
